package com.example.quiz_aw;

@interface Getter {
}
