package com.example.quiz_aw;

@interface Setter {
}
